package ezen.nowait.board.service;

public interface ReveiwService {

}
