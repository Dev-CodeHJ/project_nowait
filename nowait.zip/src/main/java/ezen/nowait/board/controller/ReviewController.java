package ezen.nowait.board.controller;

public class ReviewController {

}
