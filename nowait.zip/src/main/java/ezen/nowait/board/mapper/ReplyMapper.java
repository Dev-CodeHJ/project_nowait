package ezen.nowait.board.mapper;

public interface ReplyMapper {

}
