package ezen.nowait.board.domain;

public class ReviewVO {

}
