package ezen.nowait.member.service;

public interface UserService {

}
