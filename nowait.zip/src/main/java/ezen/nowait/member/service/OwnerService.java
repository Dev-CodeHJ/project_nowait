package ezen.nowait.member.service;

public interface OwnerService {

}
