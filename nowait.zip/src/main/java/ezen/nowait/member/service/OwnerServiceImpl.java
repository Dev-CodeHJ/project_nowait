package ezen.nowait.member.service;

public class OwnerServiceImpl {

}
