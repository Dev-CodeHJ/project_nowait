package ezen.nowait.member.mapper;

public interface OwnerMapper {

}
