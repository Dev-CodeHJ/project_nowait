package ezen.nowait.member.controller;

public class OwnerController {

}
