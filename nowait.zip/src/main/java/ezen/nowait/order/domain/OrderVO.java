package ezen.nowait.order.domain;

public class OrderVO {

}
