package ezen.nowait.order.service;

public class OrderServiceImpl {

}
