package ezen.nowait.store.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import ezen.nowait.store.domain.StoreVO;

@Mapper
public interface StoreMapper {

	public List<StoreVO> selectStoreListAll();
	
	public List<StoreVO> selectStoreListByCategory(int storeCategory);
	
	public List<StoreVO> selectStoreListByOwner(String ownerId);
	
	public int insertStore(StoreVO sVO);
	
	public int insertOwnerStore(String ownerId, String crNum, String secretCode);
	
	public StoreVO selectStore(String crNum);
	
	public int updateStore(StoreVO sVO);
	
	public int deleteStore(String crNum, String secretCode);
}
