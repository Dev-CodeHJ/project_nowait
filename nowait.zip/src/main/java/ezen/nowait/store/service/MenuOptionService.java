package ezen.nowait.store.service;

public interface MenuOptionService {

}
