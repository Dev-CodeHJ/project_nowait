package ezen.nowait.store.service;

public class MenuServiceImpl {

}
