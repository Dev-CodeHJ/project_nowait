package ezen.nowait.store.service;

import org.springframework.stereotype.Service;

@Service
public class StoreServiceImpl implements StoreService {

	
}
