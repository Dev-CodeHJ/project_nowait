package ezen.nowait.store.service;

public interface StoreService {
//
//	public List<StoreVO> storeAllList();
//	
//	public List<StoreVO> storeListByCategory(int storeCategory);
//	
//	public List<StoreVO> storeListByOwner(String ownerId);
//	
//	public int storeInsert(StoreVO sVO);
//	
//	public int ownerStoreInsert(String ownerId, String crNum, String secretCode);
//	
//	public StoreVO storeSelect(String crNum);
//	
//	public int StoreUpdate(StoreVO sVO);
//	
//	public int StoreDelete(String crNum, String secretCode);
}
