package ezen.nowait.store.mapper;

public interface MenuOptionMapper {

}
