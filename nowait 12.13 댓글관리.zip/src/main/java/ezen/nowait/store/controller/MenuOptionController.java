package ezen.nowait.store.controller;

public class MenuOptionController {

}
