package ezen.nowait.code.domain;

import lombok.Data;

@Data
public class CodeVO {

	private String crNum;
	private String id;
	private int name;
	private String value;
}
