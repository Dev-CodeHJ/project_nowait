package ezen.nowait.store.domain;

public class MenuOptionVO {

}
