package ezen.nowait.store.mapper;

public interface MenuMapper {

}
