package ezen.nowait.board.controller;

public class ReplyController {

}
