package ezen.nowait.board.service;

public class ReplyServiceImpl {

}
