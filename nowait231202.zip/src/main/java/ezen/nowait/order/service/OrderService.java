package ezen.nowait.order.service;

public interface OrderService {

}
