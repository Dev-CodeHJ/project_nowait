package ezen.nowait.order.mapper;

public interface OrderMapper {

}
